package edu;

public class Course {
    private String title;
    private int durationInHours;
    public final int maxStudents;
 // Constructor 1: Accepts title, duration, and maxStudents
    public Course(String title, int durationInHours, int maxStudents) {
        this.title = title;
        this.durationInHours = durationInHours;
        this.maxStudents = maxStudents;
    }
 // Constructor 2: Accepts only title. Overloaded constructor
    public Course(String title) {
        this(title, 0, 30); // Default duration and max students
    }
    
 // Getter for title
    public String getTitle() {
        return title;
    }

    public void showCourseDetails() {
        System.out.println("Course Title: " + title + ", Duration: " + durationInHours + " hours, Max Students: " + maxStudents);
    }
}
