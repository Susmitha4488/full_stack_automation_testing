package edu;

public class Instructor extends User {
    private String createdCourse1;
    private String createdCourse2;

    public Instructor(String name, String email, String userId) {
        super(name, email, userId);
    }

    public void createCourse(String courseName) {
        if (createdCourse1 == null) {
            createdCourse1 = courseName;
        } else if (createdCourse2 == null) {
            createdCourse2 = courseName;
        } else {
            System.out.println("Already 2 courses created!!");
        }
    }

    @Override
    public void viewProfile() {
        System.out.println("Instructor Profile: " + getName() + ", Email: " + getEmail());
    }
}
