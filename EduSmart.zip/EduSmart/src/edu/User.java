package edu;

//Abstract class User
abstract class User {
	//Instance variables
 private String name;
 private String email;
 private String userId;

 //Parameterized constructor
 public User(String name, String email, String userId) {
     this.name = name;
     this.email = email;
     this.userId = userId;
 }

//abstract method - only declaration of method in abstract class
 public abstract void viewProfile();

 public final void displayWelcome() {
     System.out.println("Welcome to ");
 }

 // Getters
 public String getName() {
     return name;
 }

 public String getEmail() {
     return email;
 }

 public String getUserId() {
     return userId;
 }
//Setter for name
 public void setName(String name) {
		this.name = name;
	}
 public void setEmail(String email) {
		this.email = email;
	}
 public void setUserId(String userId) {
		this.userId =userId;
	}
 
}
