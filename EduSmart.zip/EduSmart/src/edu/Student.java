package edu;

import java.util.ArrayList;

public class Student extends User implements ProgressTrackable {
    private ArrayList<String> enrolledCourses;

    public Student(String name, String email, String userId) {
        super(name, email, userId);
        this.enrolledCourses = new ArrayList<>();
    }

    public void enrollCourse(String courseName) {
        if (enrolledCourses.size() < 2) {
            enrolledCourses.add(courseName);
        } else {
            System.out.println("Maximum course limit reached.");
        }
    }

    @Override
    public void viewProfile() {
        System.out.println("Student Profile: " + getName() + ", Email: " + getEmail());
        System.out.println("Enrolled Courses: " + enrolledCourses);
    }

    @Override
    public void trackProgress() {
        System.out.println("Tracking progress for " + getName());
    }
}
