package edu;

public class Main {
    public static void main(String[] args) {
        // Create 2 students
        Student student1 = new Student("Kesava", "kesava03@gmail.com", "S001");
        Student student2 = new Student("Kavya", "kavya88@gmail.com", "S002");

        // Create 2 instructors
        Instructor instructor1 = new Instructor("sai", "sai357@gmail.com", "I001");
        Instructor instructor2 = new Instructor("Reshma", "reshma@gmail.com", "I002");

        // Create 1 admin
        Admin admin = new Admin("Sujith", "sujithgopal@gmail.com", "A001");

        // Instructors create courses
        Course course1 = new Course("Java Programming", 40, 30);
        Course course2 = new Course("Data Structures", 30, 30);
        instructor1.createCourse(course1.getTitle());
        instructor1.createCourse(course2.getTitle());

        // Students enroll in courses
        student1.enrollCourse(course1.getTitle());
        student2.enrollCourse(course2.getTitle());

        // Display user profiles
        student1.viewProfile();
        student2.viewProfile();
        instructor1.viewProfile();
        admin.viewProfile();

        // Students track progress
        student1.trackProgress();
        student2.trackProgress();

        // Admin removes a user
        admin.removeUser (student1);

        // Display course details
        course1.showCourseDetails();
        course2.showCourseDetails();
    }
}
