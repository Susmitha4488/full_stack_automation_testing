package edu;

//Pure abstraction -> class student extends 
public interface ProgressTrackable {
    void trackProgress();
}