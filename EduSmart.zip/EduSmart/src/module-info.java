/**
 * 
 */
/**
 * 
 */
module EduSmart {
}